select *
from DBRG.DTRGD010 as RGD010
where 
RGD010.DIV = ':DIV'
and RGD010.SYS_NO = ':SYS_NO'
and RGD010.FLOW_NO = ':FLOW_NO'
with ur