UPDATE DBRG.DTRGD010
   SET TYPE = ':TYPE',
       LST_PROC_ID = ':LST_PROC_ID',
       LST_PROC_NAME = ':LST_PROC_NAME',
       LST_PROC_DATE = ':LST_PROC_DATE',
       OP_STATUS = ':OP_STATUS'
 WHERE     DIV = ':DIV'
       AND SYS_NO = ':SYS_NO'
       AND TYPE = ':TYPE'
       AND FUT_TYPE = ':FUT_TYPE'
