select RZD040.CODE, RZD040.CHI_NM 
FROM DBRZ.DTRZD040 as RZD040
where 1=1
[and RZD040.DIV = ':DIV']
[and (RZD040.CODE like ':CODE'
OR RZD040.CHI_NM like ':CODE'
or RZD040.ENG_NM like ':CODE')]
[and RZD040.STS = '2']
[and RZD040.ACT = '0']
[and RZD040.TYPE = 'I']
with ur