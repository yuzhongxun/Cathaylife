update DBDG.DTRGD020
   set TYPE = ':strType', 
       LST_PROC_ID = ':LST_PROC_ID',
	   LST_PROC_NAME = ':LST_PROC_NAME',
	   LST_PROC_DATE = ':Current_TimeStamp',
	   OP_STATUS = ':OP_STATUS'
 where DIV =  ':DIV'
   and SYS_NO =  ':SYS_NO'
   and TYPE =  ':TYPE'
   and CONT_CODE = ':CONT_CODE';
