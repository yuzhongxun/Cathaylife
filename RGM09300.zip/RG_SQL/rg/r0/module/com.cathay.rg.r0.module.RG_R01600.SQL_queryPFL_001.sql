SELECT DISTINCT a.PFL_ACC_ID, a.PFL_ACC_NM, b.ACC_USE_TYPE
  FROM DTRGG031 a JOIN DTRGD030 b ON a.SUB_SNO = b.SUB_SNO
 WHERE a.BAL_DATE = ':BAL_DATE'
   AND a.BAL_KD = 'PFL'
  [ and a.PFL_ACC_ID = 'in:PFL_IDs' ]
  and a.SYS_NO=':SYS_NO'
  and a.DIV=':DIV'
  [ and PROD_TYPE=':PROD_TYPE' ]
  [ and a.INV_VER=':INV_VER' ]
  and b.ACT = 'Y'
  and b.TYPE = 'I'
  [ and b.ACC_USE_TYPE=':ACC_USE_TYPE' ]
  and b.OP_STATUS = 30
with ur
