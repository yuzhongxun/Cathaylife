WITH TA
     AS (SELECT max (MCHD_SYS_DT) AS MCHD_SYS_DT
           FROM DBRZ.DTRZG010
          WHERE     EOD_TP = '30'
                AND MCHD_CD = 'LF'
                AND STS_CD = '02'
                AND date (END_TM) = CURRENT DATE),
     TB
     AS (SELECT max (MCHD_SYS_DT) AS MCHD_SYS_DT
           FROM DBRZ.DTRZG010
          WHERE     EOD_TP = '30'
                AND MCHD_CD = 'RG1'
                AND STS_CD = '02'
                AND date (END_TM) = CURRENT DATE),
     TC
     AS (SELECT MCHD_SYS_DT FROM TA
         UNION
         SELECT MCHD_SYS_DT FROM TB)
SELECT min (MCHD_SYS_DT)
  FROM TC
  WITH UR