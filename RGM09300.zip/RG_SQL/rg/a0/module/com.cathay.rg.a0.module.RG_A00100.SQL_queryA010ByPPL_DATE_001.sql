SELECT * FROM DBRV.DTRGA010
    WHERE  SYS_NO = ':SYS_NO'
        AND  PPL_DATE = ':PPL_DATE' 
        AND  PFL_ID =  ':PFL_ID'
      [ AND  OP_STATUS =  ':OP_STATUS' ]
        WITH  UR