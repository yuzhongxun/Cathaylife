DELETE FROM DBRG.DTRGG021
 WHERE     SYS_NO = ':SYS_NO'
       [ AND BAL_DATE = ':BAL_DATE' ]
       [ AND PFL_ACC_ID = ':PFL_ACC_ID' ]
       [ AND TRD_NO = ':TRD_NO' ]
       [ AND TRD_SER_NO = ':TRD_SER_NO' ]
       [ AND LTRD_NO = ':LTRD_NO' ]
       [ AND LTRD_SER_NO = ':LTRD_SER_NO' ]
       [ AND TRD_KND = ':TRD_KND' ]
       [ AND BAL_KD = ':BAL_KD' ]
       [ AND OFFSET_TYPE = ':OFFSET_TYPE' ]
