DELETE FROM DBRG.DTRGG031
 WHERE     SYS_NO = ':SYS_NO'
      [ AND BAL_DATE = ':BAL_DATE' ]
      [ AND BAL_KD = ':BAL_KD' ]
      [ AND INV_VER = ':INV_VER' ]
      [ AND PFL_ACC_ID = ':PFL_ACC_ID' ]
      [ AND SUB_SNO = ':SUB_SNO' ]
