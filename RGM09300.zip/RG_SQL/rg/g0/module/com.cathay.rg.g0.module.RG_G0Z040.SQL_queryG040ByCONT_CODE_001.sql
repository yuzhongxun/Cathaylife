SELECT *
  FROM DBRG.DTRGG040
 WHERE     SYS_NO = ':SYS_NO'
       AND DIV = ':DIV'
      [ AND BAL_DATE >= ':BAL_DATE_STR' ]
      [ AND BAL_DATE <= ':BAL_DATE_END' ]
      [ AND INV_VER = ':INV_VER' ]
      [ AND BAL_KD = ':BAL_KD' ]
      [ AND PFL_ACC_ID = 'in:PFL_ACC_IDs' ]
      [ AND ORG_ID = 'in:ORG_IDs' ]
      [ AND TRD_ACNT_NO = 'in:TRD_ACNT_NOs' ]
      [ AND CRC = 'in:CRCs' ]
ORDER BY BAL_DATE,
         INV_VER,
         BAL_KD,
         PFL_ACC_ID,
         TRD_ACNT_NO,
         CRC
  WITH UR