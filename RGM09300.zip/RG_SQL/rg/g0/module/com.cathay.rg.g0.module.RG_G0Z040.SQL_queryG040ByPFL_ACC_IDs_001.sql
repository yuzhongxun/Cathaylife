SELECT *
  FROM DBRG.DTRGG040
 WHERE     SYS_NO = ':SYS_NO'
      [ AND BAL_DATE = ':BAL_DATE' ]
      [ AND BAL_KD = ':BAL_KD' ]
      [ AND INV_VER = ':INV_VER' ]
      [ AND PFL_ACC_ID = 'in:PFL_ACC_IDs' ]
      [ AND SUB_SNO = 'in:SUB_SNOs' ]
ORDER BY BAL_DATE,
         INV_VER,
         BAL_KD,
         PFL_ACC_ID,
         SUB_SNO
  WITH UR