SELECT *
  FROM DBRG.DTRGK020
 WHERE     SYS_NO = ':SYS_NO'
      [ AND APP_DATE >= ':APP_DATE_STR' ]
      [ AND APP_DATE <= ':APP_DATE_END' ]
      [ AND PFL_ID = ':PFL_ID' ]
      [ AND ACC_SEC_ID = ':ACC_SEC_ID' ]
      [ AND OP_STATUS >= ':OP_STATUS' ]
ORDER BY APP_NO
  WITH UR