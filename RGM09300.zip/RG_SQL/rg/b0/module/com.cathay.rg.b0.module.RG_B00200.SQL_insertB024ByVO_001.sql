INSERT INTO DBRG.DTRGB024 (SYS_NO
      ,DIV
      ,TRAN_NO
      ,FILE_ID
      ,LST_PROC_ID
      ,LST_PROC_NAME
      ,LST_PROC_DATE)
VALUES (':SYS_NO'
       ,':DIV'
       ,':TRAN_NO'
       ,':FILE_ID'
       ,':LST_PROC_ID'
       ,':LST_PROC_NAME'
       ,':LST_PROC_DATE')