UPDATE DBRG.DTRGB012
   SET TRD_DATE = ':TRD_DATE',
       ACNT_DATE = ':ACNT_DATE',
       CONT_CODE = ':CONT_CODE',
       CONT_OCODE = ':CONT_OCODE',
       CONT_NAME = ':CONT_NAME',
       BLG_CD = ':BLG_CD',
       BS_TYPE = ':BS_TYPE',
       OFFSET_TYPE = ':OFFSET_TYPE',
       UNIT = ':UNIT',
       OFFSET_UNIT = ':OFFSET_UNIT',
       TRD_PRICE = ':TRD_PRICE',
       STR_PRICE = ':STR_PRICE'
 WHERE     SYS_NO = ':SYS_NO'
       AND TRD_NO = ':TRD_NO'
       AND LTRD_NO = ':LTRD_NO'
       AND TRD_SER_NO = ':TRD_SER_NO'
       AND LTRD_SER_NO = ':LTRD_SER_NO'