UPDATE DBRG.DTRGB011
   SET 
       CONT_CODE = ':CONT_CODE',
       CONT_OCODE = ':CONT_OCODE',
       CONT_NAME = ':CONT_NAME',
       BLG_CD = ':BLG_CD',
       BS_TYPE = ':BS_TYPE',
       OFFSET_TYPE = ':OFFSET_TYPE',
       UNIT = ':UNIT',
       TRD_PRICE = ':TRD_PRICE',
       TAX_O = ':TAX_O',
       FEE_O = ':FEE_O',
       TOT_FEE_O = ':TOT_FEE_O',
       STR_PRICE = ':STR_PRICE',
       PREM_FEE_O = ':PREM_FEE_O',
       IS_EXE_FUT = ':IS_EXE_FUT'
 WHERE     SYS_NO = ':SYS_NO'
       AND TRD_NO = ':TRD_NO'
       AND TRD_SER_NO = ':TRD_SER_NO'