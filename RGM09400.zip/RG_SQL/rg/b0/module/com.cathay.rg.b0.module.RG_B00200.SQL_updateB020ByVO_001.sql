UPDATE DBRG.DTRGB020
   SET DIV = ':DIV',
       ACNT_DATE = ':ACNT_DATE',
       MGN_DEP_ID = ':MGN_DEP_ID',
       MGN_DEP_NM = ':MGN_DEP_NM',
       MGN_SEC_ID = ':MGN_SEC_ID',
       MGN_SEC_NM = ':MGN_SEC_NM',
       REMARK = ':REMARK',
       LST_PROC_ID = ':LST_PROC_ID',
       LST_PROC_NAME = ':LST_PROC_NAME',
       LST_PROC_DATE = ':LST_PROC_DATE',
       OP_STATUS = ':OP_STATUS',
       FLOW_NO = ':FLOW_NO'
 WHERE SYS_NO = ':SYS_NO' AND TRAN_NO = ':TRAN_NO'