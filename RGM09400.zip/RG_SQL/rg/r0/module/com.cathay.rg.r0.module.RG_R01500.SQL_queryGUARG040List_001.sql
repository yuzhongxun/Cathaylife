WITH TA
     AS (SELECT SYS_NO,
                BAL_DATE,
                BAL_KD,
                INV_VER,
                ORG_ID,
                TRD_ACNT_NO,
                PFL_ACC_ID,
                SUB_SNO,
                CRC,
                DAY_CASH_BAL_O AS LDAY_CASH_BAL_O,
                DAY_CASH_BAL_T AS LDAY_CASH_BAL_T
           FROM DTRGG040
          WHERE     SYS_NO = ':SYS_NO'
                AND DIV = ':DIV'
                AND BAL_DATE = ':PRE_DATE'
                AND BAL_KD = ':BAL_KD'
                AND INV_VER = 'D'
                AND PFL_ACC_ID = 'in:PFL_IDs')
SELECT TA.LDAY_CASH_BAL_O,
       TA.LDAY_CASH_BAL_T,
       G040.PFL_ACC_ID,
       G040.PFL_ACC_NM,
       G040.SUB_SNO,
       G040.SUB_ACNT_ID,
       G040.SUB_ACNT_NM,
       G040.ORG_SRT_NM,
       G040.CRC,
       G040.DAY_IN_AMT,
       G040.DAY_OUT_AMT,
       G040.DAY_NET_INT_O,
       G040.DAY_NET_INT_T,
       G040.DAY_RL_BENET_O,
       G040.DAY_RL_BENET_T,
       G040.DAY_PREM_FEE_O,
       G040.DAY_PREM_FEE_T,
       G040.DAY_FEE_O,
       G040.DAY_FEE_T,
       G040.DAY_CASH_BAL_O,
       G040.DAY_CASH_BAL_T,
       G040.FUT_UN_TRD_BENET_O,
       G040.FUT_UN_TRD_BENET_T,
       G040.BENEFIT_O,
       G040.BENEFIT_T,
       G040.OPT_BUY_MKT_VAL_O,
       G040.OPT_BUY_MKT_VAL_T,
       G040.OPT_SELL_MKT_VAL_O,
       G040.OPT_SELL_MKT_VAL_T,
       G040.FUT_GUAR_AMT_O + G040.OPT_GUAR_AMT_O AS GUAR_AMT_O, 
       G040.FUT_GUAR_AMT_T + G040.OPT_GUAR_AMT_T AS GUAR_AMT_T, 
       G040.FUT_LGUAR_AMT_O + G040.OPT_LGUAR_AMT_O AS LGUAR_AMT_O, 
       G040.FUT_LGUAR_AMT_T + G040.OPT_LGUAR_AMT_T AS LGUAR_AMT_T, 
       G040.EXC_LSS_AMT_O,
       G040.EXC_LSS_AMT_T
  FROM    DTRGG040 G040
       LEFT JOIN
          TA
       ON     G040.SYS_NO = TA.SYS_NO
          AND G040.BAL_KD = TA.BAL_KD          
          AND G040.ORG_ID = TA.ORG_ID
          AND G040.TRD_ACNT_NO = TA.TRD_ACNT_NO
          AND G040.PFL_ACC_ID = TA.PFL_ACC_ID
          AND G040.SUB_SNO = TA.SUB_SNO
          AND G040.CRC = TA.CRC
 WHERE     G040.SYS_NO = ':SYS_NO'
       AND G040.DIV = ':DIV'
       AND G040.BAL_DATE = ':BAL_DATE'
       AND G040.BAL_KD = ':BAL_KD'
       AND G040.INV_VER = ':INV_VER'
       AND G040.PFL_ACC_ID = 'in:PFL_IDs'
  WITH UR
