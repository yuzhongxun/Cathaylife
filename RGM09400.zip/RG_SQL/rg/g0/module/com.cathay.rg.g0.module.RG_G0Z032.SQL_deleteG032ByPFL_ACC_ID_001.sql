DELETE FROM DBRG.DTRGG032
 WHERE     SYS_NO = ':SYS_NO'
       [ AND BAL_DATE = ':BAL_DATE']
       [ AND BAL_KD = ':BAL_KD']
       [ AND INV_VER = ':INV_VER']       
       [ AND PFL_ACC_ID = ':PFL_ACC_ID']
       [ AND CONT_CODE = ':CONT_CODE']
