SELECT *
  FROM DBRG.DTRGG040
 WHERE     SYS_NO = ':SYS_NO'
      [ AND BAL_DATE >= ':BAL_DATE_STR' ]
      [ AND BAL_DATE <= ':BAL_DATE_END' ]
      [ AND BAL_KD = 'in:BAL_KDS' ]
      [ AND INV_VER = ':INV_VER' ]
      [ AND PFL_ACC_ID = ':PFL_ACC_ID' ]
      [ AND SUB_SNO = ':SUB_SNO' ]
      [ AND ORG_ID = ':ORG_ID' ]
      [ AND TRD_ACNT_NO = ':TRD_ACNT_NO' ]
      [ AND CRC = ':CRC' ]
      [ AND DIV = ':DIV' ]
ORDER BY BAL_DATE,
         INV_VER,
         BAL_KD,
         PFL_ACC_ID,
         SUB_SNO,
         TRD_ACNT_NO,
         CRC
  WITH UR
