SELECT BAL_DATE,
       INV_VER,
       BAL_KD,
       PFL_ACC_ID,
       CONT_CODE,
       CONT_OCODE,
       SUB_SNO,
       SUB_ACNT_ID,
       BS_TYPE,
       UN_OFFSET_UNIT
  FROM DBRG.DTRGG030
 WHERE SYS_NO = ':SYS_NO'
        [ AND BAL_DATE =  
           (SELECT max(BAL_DATE) FROM DBRG.DTRGG030 
                  WHERE   BAL_DATE<=  ':BAL_DATE' AND BAL_KD =  ':BAL_KD' AND INV_VER = ':INV_VER' AND PFL_ACC_ID = ':PFL_ACC_ID' 
                        AND CONT_CODE = ':CONT_CODE' AND SUB_SNO = ':SUB_SNO' AND DIV = ':DIV'
                   )]
        [ AND BAL_KD = ':BAL_KD']
        [ AND INV_VER = ':INV_VER']
        [ AND PFL_ACC_ID = ':PFL_ACC_ID']
        [ AND CONT_CODE = ':CONT_CODE']
        [ AND SUB_SNO = ':SUB_SNO']
        [ AND DIV = ':DIV']
        ORDER BY BAL_DATE, INV_VER, BAL_KD, PFL_ACC_ID
        WITH UR
