DELETE FROM DBRG.DTRGG020
 WHERE     SYS_NO = ':SYS_NO'
       [ AND BAL_DATE = ':BAL_DATE' ]
       [ AND PFL_ACC_ID = ':PFL_ACC_ID' ]
       [ AND TRD_NO = ':TRD_NO' ]
       [ AND TRD_KND = ':TRD_KND' ]
       [ AND BAL_KD = ':BAL_KD' ]
       [ AND ORG_ID = ':ORG_ID' ]
       [ AND TRD_ACNT_NO = ':TRD_ACNT_NO' ]
       [ AND SUB_SNO = ':SUB_SNO' ]