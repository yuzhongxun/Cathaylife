SELECT *
  FROM DBRG.DTRGG020
 WHERE SYS_NO      = ':SYS_NO' 
   AND DIV         = ':DIV' 
 [ AND BAL_DATE    = ':BAL_DATE']
 [ AND ACNT_DATE   = ':ACNT_DATE']
 [ AND TRD_DATE    = ':TRD_DATE']
 [ AND PFL_ACC_ID  = 'in:PFL_ACC_ID']
 [ AND BAL_KD      = 'in:BAL_KD' ]
 [ AND TRD_KND     = 'in:TRD_KND' ]
 [ AND TRD_NO      = ':TRD_NO' ]
 [ AND TRD_SER_NO  = ':TRD_SER_NO' ]
 [ AND ORG_ID      = ':ORG_ID' ]
 [ AND TRD_ACNT_NO = ':TRD_ACNT_NO' ]
 [ AND SUB_SNO     = ':SUB_SNO' ]  
 ORDER BY BAL_DATE, PFL_ACC_ID, TRD_KND, TRD_SER_NO, SUB_ACNT_ID
  WITH UR 