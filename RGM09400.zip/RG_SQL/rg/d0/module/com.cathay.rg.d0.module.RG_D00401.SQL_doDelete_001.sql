DELETE FROM DTRGD040
 WHERE     DIV = ':DIV'
       AND SYS_NO = ':SYS_NO'
       AND TYPE = ':TYPE'    
       AND OP_STATUS = ':OP_STATUS'
       AND PFL_SNO = ':PFL_SNO'
