UPDATE DBRG.DTRGM030
   SET REMARK = ':REMARK',
       LST_PROC_ID = ':EmpID',
       LST_PROC_NAME = ':EmpName',
       LST_PROC_DATE = ':CURRENT'
 WHERE     DIV = ':DIV'
       AND SYS_NO = ':SYS_NO'
       AND BAL_DATE = ':BAL_DATE'
       AND CONT_CODE = ':CONT_CODE'
