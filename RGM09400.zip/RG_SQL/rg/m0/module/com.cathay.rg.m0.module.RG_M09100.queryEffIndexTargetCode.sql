select RZD044.CODE, RZD044.CHI_NM 
FROM DBRZ.DTRZD044 as RZD044
where 1=1
[and RZD044.DIV = ':DIV']
[and (RZD044.CODE like ':CODE'
OR RZD044.CHI_NM like ':CODE'
or RZD044.ENG_NM like ':CODE')]
[and RZD044.STS = '2']
[and RZD044.ACT = '0']
[and RZD044.TYPE = 'I']
with ur
