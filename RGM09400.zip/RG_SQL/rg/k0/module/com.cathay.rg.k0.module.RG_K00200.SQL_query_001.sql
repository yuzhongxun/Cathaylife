SELECT *
  FROM DBRG.DTRGK020
 WHERE     SYS_NO = ':SYS_NO'
      [ AND DIV = ':DIV' ]
      [ AND APP_DATE >= ':APP_DATE_STR' ]
      [ AND APP_DATE <= ':APP_DATE_END' ]
      [ AND ORG_ID = ':ORG_ID' ]
      [ AND PFL_ID = ':PFL_ID' ]
      [ AND ACC_SEC_ID = ':ACC_SEC_ID' ]
      [ AND APP_KIND = ':APP_KIND' ]
      [ AND CRC = ':CRC' ]
      [ AND OP_STATUS = ':OP_STATUS' ]
ORDER BY APP_NO
  WITH UR