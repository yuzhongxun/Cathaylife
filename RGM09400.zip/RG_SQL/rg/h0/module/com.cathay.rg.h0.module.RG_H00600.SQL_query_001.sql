SELECT *
FROM DBRG.DTRGG040
WHERE SYS_NO = ':SYS_NO'               
  AND BAL_KD = 'SUB'                    
[ AND BAL_DATE >= ':BAL_DATE_STR']     
[ AND BAL_DATE <= ':BAL_DATE_END']     
[ AND INV_VER = 'in:INV_VERs' ]         
[ AND SUB_SNO = 'in:SUB_SNOs']        
[ AND ORG_ID = 'in:ORG_IDs']            
ORDER BY BAL_DATE, SUB_ACNT_ID, ORG_ID0
  WITH UR
