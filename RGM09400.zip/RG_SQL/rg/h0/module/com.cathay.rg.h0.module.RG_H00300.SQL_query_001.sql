 SELECT *
FROM DBRG.DTRGG032
WHERE SYS_NO = ':SYS_NO'                
  AND BAL_KD = ':BAL_KD'                
[ AND BAL_DATE >= ':BAL_DATE_STR' ]   
[ AND BAL_DATE <= ':BAL_DATE_END' ]     
[ AND INV_VER = 'in:INV_VERs' ]        
[ AND PFL_ACC_ID = 'in:PFL_ACC_IDs' ]   
[ AND CONT_CODE = 'in:CONT_CODEs' ]    
[ AND PROD_TYPE = 'in:PROD_TYPEs' ]     
[ AND UN_OFFSET_UNIT > ':UN_OFFSET_UNIT_DISPLAY' ] 
ORDER BY BAL_DATE, PFL_ACC_ID,CONT_OCODE 
WITH UR