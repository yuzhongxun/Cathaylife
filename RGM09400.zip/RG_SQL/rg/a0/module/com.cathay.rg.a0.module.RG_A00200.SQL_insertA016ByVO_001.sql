INSERT INTO 
   DBRG.DTRGA016 (SYS_NO,
   DIV,
   PPL_NO,
   PRT_TP,
   PRT_ITEM)
   VALUES (':SYS_NO',
	':DIV',
	':PPL_NO',
	':PRT_TP',
	':PRT_ITEM')