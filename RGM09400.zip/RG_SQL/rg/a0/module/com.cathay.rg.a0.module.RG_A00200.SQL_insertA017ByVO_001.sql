INSERT INTO DBRG.DTRGA017 (PPL_NO,
                           SYS_NO,
                           DIV,
                           PPL_STY)
VALUES (':PPL_NO',
        ':SYS_NO',
        ':DIV',
        ':PPL_STY')