package com.cathay.rg.m0.module;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.rg.vo.DTRGD030;
import com.cathay.rz.n0.module.RZ_N0Z001;
import com.cathay.rz.z0.module.RZ_Z0Z002;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Version Description Author 
 * 2017/11/07 1.0 Create �E���V
 * �@�B �{���\�෧�n�����G 
 * �ҲզW�� ��ڴ��f���f�Ӥl�b��������@�Ҳ�
 * �Ҳ�ID RG_M09300
 * ���n���� �����ڴ��f���f�Ӥl�b��������@�@�~
 * </pre>
 * 
 * @author �E���V
 * @since 2017-11-07
 * 
 */
@SuppressWarnings( { "unchecked", "deprecation" })
public class RG_M09300 {

    private static final String SQL_queryList_001 = "com.cathay.rg.m0.module.RG_M09300.SQL_queryList_001";

    private static final String SQL_queryRGD030ByPK_001 = "com.cathay.rg.m0.module.RG_M09300.SQL_queryRGD030ByPK_001";

    private static final String SQL_queryRGD030ByACNT_001 = "com.cathay.rg.m0.module.RG_M09300.SQL_queryRGD030ByACNT_001";

    private static final String SQL_queryRGD030ByFLOW_NO_001 = "com.cathay.rg.m0.module.RG_M09300.SQL_queryRGD030ByFLOW_NO_001";

    private static final String SQL_queryEffRGD030_001 = "com.cathay.rg.m0.module.RG_M09300.SQL_queryEffRGD030_001";

    private static final String SQL_queryEffD030List_001 = "com.cathay.rg.m0.module.RG_M09300.SQL_queryEffD030List_001";

    private static final String SQL_queryEffSubAcntInfoList_001 = "com.cathay.rg.m0.module.RG_M09300.SQL_queryEffSubAcntInfoList_001";

    /**
     * �d�ߤl�b����f�ӳ]�w��
     * @param reqMap
     * @param DIV
     * @param SYS_NO
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap, String DIV, String SYS_NO) throws ModuleException {

        ErrorInputException eie = null;

        if (reqMap == null) {
            eie = getErrorInputException(eie, "�ǤJ�ѼƤ��i����");
        }
        if (StringUtils.isBlank(DIV)) {
            eie = getErrorInputException(eie, "���q�O���i����");
        }
        if (StringUtils.isBlank(SYS_NO)) {
            eie = getErrorInputException(eie, "�ӫ~�O���i����");
        }
        if (eie != null) {
            throw eie;
        }

        // �̶ǤJ����d�ߤl�b����f�ӳ]�w��(DTRGD030)
        DataSet ds = Transaction.getDataSet();
        ds.setField("DIV", DIV);
        ds.setField("SYS_NO", SYS_NO);

        //TODO SQL��즳[],�D���n��J���������,�ݭn��if�P�_�����ˬd
        String ORG_ID = MapUtils.getString(reqMap, "ORG_ID"); //���c�N�����X
        if (StringUtils.isNotEmpty(ORG_ID)) {
            ds.setField("ORG_ID", ORG_ID);
        }
        String TRD_ACNT_NO = MapUtils.getString(reqMap, "TRD_ACNT_NO"); //���b��b��
        if (StringUtils.isNotEmpty(TRD_ACNT_NO)) {
            ds.setField("TRD_ACNT_NO", TRD_ACNT_NO);
        }
        String SUB_ACNT_NO = MapUtils.getString(reqMap, "SUB_ACNT_NO"); //�l�b��b��
        if (StringUtils.isNotEmpty(SUB_ACNT_NO)) {
            ds.setField("SUB_ACNT_NO", "%" + SUB_ACNT_NO + "%");
        }
        String SUB_ACNT_ID = MapUtils.getString(reqMap, "SUB_ACNT_ID"); //�l�b��b��
        if (StringUtils.isNotEmpty(SUB_ACNT_ID)) {
            ds.setField("SUB_ACNT_ID", "%" + SUB_ACNT_ID + "%");
        }
        String SUB_ACNT_NM = MapUtils.getString(reqMap, "SUB_ACNT_NM"); //�l�b��W��
        if (StringUtils.isNotEmpty(SUB_ACNT_NM)) {
            ds.setField("SUB_ACNT_NM", "%" + SUB_ACNT_NM + "%");
        }
        String ACC_USE_TYPE = MapUtils.getString(reqMap, "ACC_USE_TYPE"); //�b������
        if (StringUtils.isNotEmpty(ACC_USE_TYPE)) {
            ds.setField("ACC_USE_TYPE", ACC_USE_TYPE);
        }
        String ACT = MapUtils.getString(reqMap, "ACT"); //�Ұ�
        if (StringUtils.isNotEmpty(ACT)) {
            ds.setField("ACT", ACT);
        }
        String OP_STATUS = MapUtils.getString(reqMap, "OP_STATUS"); //�@�~�i��
        if (StringUtils.isNotEmpty(OP_STATUS)) {
            ds.setField("OP_STATUS", OP_STATUS);
        }
        String TYPE = MapUtils.getString(reqMap, "TYPE"); //���A
        if (StringUtils.isNotEmpty(TYPE)) {
            ds.setField("TYPE", TYPE);
        }

        //�z�L�f��Ҳը��o�f�媬�A����
        // ���o�f�媬�A����
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryList_001);
        new RZ_N0Z001().putOP_STATUS_NM(rtnList, "RGD0-0300");

        //�v���B�zrtnList
        //�b����������, �Ұʤ���, ���A����
        for (Map rtnMap : rtnList) {
            rtnMap.put("ACC_USE_TYPE_NM", new RZ_Z0Z002().getCodeName("RG", "ACC_USE_TYPE", MapUtils.getString(rtnMap, "ACC_USE_TYPE")));
            rtnMap.put("ACT_NM", new RZ_Z0Z002().getCodeName("RG", "ACT", MapUtils.getString(rtnMap, "ACT")));
            rtnMap.put("TYPE_NM", new RZ_Z0Z002().getCodeName("RG", "TYPE", MapUtils.getString(rtnMap, "TYPE")));
        }
        return rtnList;
    }

    /**
     * �d�ߤl�b����f�ӳ]�wBy���H
     * @param TYPE
     * @param SUB_SNO
     * @param DIV
     * @param SYS_NO
     * @return
     * @throws ModuleException
     */
    public DTRGD030 queryRGD030ByPK(String TYPE, String SUB_SNO, String DIV, String SYS_NO) throws ModuleException {

        ErrorInputException eie = null;

        if (StringUtils.isBlank(TYPE)) {
            eie = getErrorInputException(eie, "���A���i����");
        }
        if (StringUtils.isBlank(SUB_SNO)) {
            eie = getErrorInputException(eie, "�l�b�᤺���N�����i����");
        }
        if (StringUtils.isBlank(DIV)) {
            eie = getErrorInputException(eie, "���q�O���i����");
        }
        if (StringUtils.isBlank(SYS_NO)) {
            eie = getErrorInputException(eie, "�ӫ~�O���i����");
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("DIV", DIV);
        ds.setField("SYS_NO", SYS_NO);
        ds.setField("SUB_SNO", SUB_SNO);
        ds.setField("TYPE", TYPE);

        return VOTool.findOneToVO(DTRGD030.class, ds, SQL_queryRGD030ByPK_001);
    }

    /**
     * �d�ߤl�b����f�ӳ]�wBy�b��
     * @param ORG_ID
     * @param TRD_ACNT_NO
     * @param SUB_ACNT_ID
     * @param DIV
     * @param SYS_NO
     * @param TYPE
     * @return
     * @throws ModuleException
     */
    public DTRGD030 queryRGD030ByACNT(String ORG_ID, String TRD_ACNT_NO, String SUB_ACNT_ID, String DIV, String SYS_NO, String TYPE)
            throws ModuleException {

        ErrorInputException eie = null;

        if (StringUtils.isBlank(ORG_ID)) {
            eie = getErrorInputException(eie, "���f�Ӥ��i����");
        }
        if (StringUtils.isBlank(TRD_ACNT_NO)) {
            eie = getErrorInputException(eie, "���b��b�����i����");
        }
        if (StringUtils.isBlank(SUB_ACNT_ID)) {
            eie = getErrorInputException(eie, "�l�b��N�����i����");
        }
        if (StringUtils.isBlank(DIV)) {
            eie = getErrorInputException(eie, "���q�O���i����");
        }
        if (StringUtils.isBlank(SYS_NO)) {
            eie = getErrorInputException(eie, "�ӫ~�O���i����");
        }
        if (StringUtils.isBlank(TYPE)) {
            eie = getErrorInputException(eie, "���A���i����");
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("DIV", DIV);
        ds.setField("SYS_NO", SYS_NO);
        ds.setField("ORG_ID", ORG_ID);
        ds.setField("TRD_ACNT_NO", TRD_ACNT_NO);
        ds.setField("SUB_ACNT_ID", SUB_ACNT_ID);
        if (StringUtils.isNotEmpty(TYPE)) {
            ds.setField("TYPE", TYPE);
        }

        return VOTool.findOneToVO(DTRGD030.class, ds, SQL_queryRGD030ByACNT_001);
    }

    /**
     * �d�ߤl�b����f�ӳ]�wBy�f��y�{�s��
     * @param PFL_ID
     * @param DIV
     * @param SYS_NO
     * @param TYPE
     * @param OP_STATUS
     * @return
     * @throws ModuleException
     */
    public DTRGD030 queryRGD030ByFLOW_NO(String FLOW_NO, String DIV, String SYS_NO) throws ModuleException {

        ErrorInputException eie = null;

        if (StringUtils.isBlank(FLOW_NO)) {
            eie = getErrorInputException(eie, "�f��y�{�s�����i����");
        }
        if (StringUtils.isBlank(DIV)) {
            eie = getErrorInputException(eie, "���q�O���i����");
        }
        if (StringUtils.isBlank(SYS_NO)) {
            eie = getErrorInputException(eie, "�ӫ~�O���i����");
        }
        if (eie != null) {
            throw eie;
        }

        // �ھ� reqMap �����u�s���P���N�����d�߱���
        DataSet ds = Transaction.getDataSet();
        ds.setField("DIV", DIV);
        ds.setField("SYS_NO", SYS_NO);
        ds.setField("FLOW_NO", FLOW_NO);

        return VOTool.findOneToVO(DTRGD030.class, ds, SQL_queryRGD030ByFLOW_NO_001);
    }

    /**
     * �d�ߦ��Ī��l�b����f�ӳ]�w
     * @param ORG_ID
     * @param TRD_ACNT_ID
     * @param SUB_ACNT_ID
     * @param DIV
     * @param SYS_NO
     * @return
     * @throws ModuleException
     */
    public List<DTRGD030> queryEffRGD030(String ORG_ID, String TRD_ACNT_NO, String SUB_ACNT_ID, String DIV, String SYS_NO)
            throws ModuleException {

        ErrorInputException eie = null;

        if (StringUtils.isBlank(ORG_ID)) {
            eie = getErrorInputException(eie, "���f�ӥN�����i����");
        }
        if (StringUtils.isBlank(TRD_ACNT_NO)) {
            eie = getErrorInputException(eie, "���b��b�����i����");
        }
        if (StringUtils.isBlank(SUB_ACNT_ID)) {
            eie = getErrorInputException(eie, "�l�b��N�����i����");
        }
        if (StringUtils.isBlank(DIV)) {
            eie = getErrorInputException(eie, "���q�O���i����");
        }
        if (StringUtils.isBlank(SYS_NO)) {
            eie = getErrorInputException(eie, "�ӫ~�O���i����");
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        // �d�ߤl�b����f�ӳ]�w��
        ds.setField("DIV", DIV);
        ds.setField("SYS_NO", SYS_NO);
        if (StringUtils.isNotEmpty(ORG_ID)) {
            ds.setField("ORG_ID", ORG_ID);
        }
        if (StringUtils.isNotEmpty(TRD_ACNT_NO)) {
            ds.setField("TRD_ACNT_NO", TRD_ACNT_NO);
        }
        if (StringUtils.isNotEmpty(SUB_ACNT_ID)) {
            ds.setField("SUB_ACNT_ID", SUB_ACNT_ID);
        }

        return VOTool.findToVOs(DTRGD030.class, ds, SQL_queryEffRGD030_001);
    }

    /**
     * �d�ߦ��Ī��l�b����f�ӳ]�w
     * @param SUB_SNO
     * @param DIV
     * @param SYS_NO
     * @return
     * @throws ModuleException
     */
    public List<DTRGD030> queryEffD030List(String SUB_SNO, String DIV, String SYS_NO) throws ModuleException {

        ErrorInputException eie = null;

        if (StringUtils.isBlank(SUB_SNO)) {
            eie = getErrorInputException(eie, "�l�b�᤺���N�����i����");
        }
        if (StringUtils.isBlank(DIV)) {
            eie = getErrorInputException(eie, "���q�O���i����");
        }
        if (StringUtils.isBlank(SYS_NO)) {
            eie = getErrorInputException(eie, "�ӫ~�O���i����");
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("DIV", DIV);
        ds.setField("SYS_NO", SYS_NO);
        if (StringUtils.isNotEmpty(SUB_SNO)) { //PK�n�ˮ�
            ds.setField("SUB_SNO", SUB_SNO);
        }

        return VOTool.findToVOs(DTRGD030.class, ds, SQL_queryEffD030List_001);
    }

    /**
     * �d�ߦ��Ĥl�b����f�ӳ]�w��
     * @param reqMap
     * @param DIV
     * @param SYS_NO
     * @return
     * @throws ModuleException
     */
    public List<Map> queryEffSubAcntInfoList(Map reqMap, String DIV, String SYS_NO) throws ModuleException {

        ErrorInputException eie = null;

        if (reqMap == null) {
            eie = getErrorInputException(eie, "�ǤJ�ѼƤ��i����");
        }
        if (StringUtils.isBlank(DIV)) {
            eie = getErrorInputException(eie, "���q�O���i����");
        }
        if (StringUtils.isBlank(SYS_NO)) {
            eie = getErrorInputException(eie, "�ӫ~�O���i����");
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("DIV", DIV);
        ds.setField("SYS_NO", SYS_NO);
        String SUB_ACNT_INFO = MapUtils.getString(reqMap, "SUB_ACNT_INFO"); //�l�b���T 
        if (StringUtils.isNotEmpty(SUB_ACNT_INFO)) {
            ds.setField("SUB_ACNT_INFO", "%" + SUB_ACNT_INFO + "%");
        }
        //�z�L�f��Ҳը��o�f�媬�A����
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryEffSubAcntInfoList_001);
        new RZ_N0Z001().putOP_STATUS_NM(rtnList, "RGD0-0300");

        //�v���B�zrtnList
        //�b����������, �Ұʤ���, ���A����
        RZ_Z0Z002 theRZ_Z0Z002 = new RZ_Z0Z002();
        for (Map rtnMap : rtnList) {
            rtnMap.put("ACC_USE_TYPE_NM", theRZ_Z0Z002.getCodeName("RG", "ACC_USE_TYPE", MapUtils.getString(rtnMap, "ACC_USE_TYPE")));
            rtnMap.put("ACT_NM", theRZ_Z0Z002.getCodeName("RG", "ACT", MapUtils.getString(rtnMap, "ACT")));
            rtnMap.put("TYPE_NM", theRZ_Z0Z002.getCodeName("RG", "TYPE", MapUtils.getString(rtnMap, "TYPE")));
        }

        return rtnList;
    }

    /**
     * ErrorInputException ���~�T���B�z
     * @param eie
     * @param errMsg
     * @return
     */

    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg); // eie��^errMsg
        return eie;
    }
}
